<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Primer Proyecto Boostrap</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="./css/miestilo.css">
</head>
<body>
	<header>
		<h1></h1>
	</header>
	<main>
		<div class="container">
      		<div class="row">
	        	<div class="col-md-6 offset-md-3">
	        		<form enctype="multipart/form-data" action="recibeDatos" method="post">
					<section>
						<h2>Formulario</h2>
						<label for="nombre">Nombre:</label>
						<input type="text" name="nombre" id="nombre" required="required" />
						<br>
						<label for="Pais">Pais</label>
						<select name="pais"  class="form-control" >
							<option value="">-- Seleciona una opcion</option>
							<option value="es">España</option>
							<option value="fr">Francia</option>
							<option value="it">Italia</option>
						</select>
						<label>Genero:</label><br>
							<input type="radio" name="genero" value="H" checked="checked">Hombre
							<input type="radio" name="genero" value="M">Mujer
							<br>
						<textarea name="mensaje" class="form-control" style="resize: none;"
						placeholder="Escribe un mensaje"></textarea>
					</section>
					<br>
					<label>Afficciones:</label>
					<input type="checkbox" name="aficciones[]" value="musica">
					<label for="musica">Musica</label>
					<input type="checkbox" name="aficciones[]" value="deporte">
					<label for="deporte">Deporte</label>
						<br>
						
						<!-- MAX_FILE_SIZE debe preceder al campo de entrada del fichero -->
    <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
    <!-- El nombre del elemento de entrada determina el nombre en el array $_FILES  /* file[] multiple="multiple" */-->
    									
					 <input type="file" name="ficheros[]" id="file"  multiple="multiple">
					<br><br>
					<input type="submit" name="envio" value="Enviar Datos">
					</form>

				</div>
			</div>
		</div>
	</main>
	<footer>
	</footer>
</body>
</html>