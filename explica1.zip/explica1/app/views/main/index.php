<!DOCTYPE html>
<html>
<head>
	<title>Tipo booleano</title>
</head>
<body>
	<a href="main/formulario">Ver Formulario</a>
	<hr>

<?php

var_dump((bool) "");        // bool(false)
echo "<br>";
var_dump((bool) 1);         // bool(true)
echo "<br>";
var_dump((bool) -2);        // bool(true)
echo "<br>";
var_dump((bool) "foo");     // bool(true)
echo "<br>";
var_dump((bool) 2.3e5);     // bool(true)
echo "<br>";
var_dump((bool) array(12)); // bool(true)
echo "<br>";
var_dump((bool) array());   // bool(false)
echo "<br>";
var_dump((bool) "false");   // bool(true)
echo "<hr>";

$a = 1234; // decimal number
var_dump($a);
echo "<br>";
$a = 0123; // octal number (equivalent to 83 decimal)
var_dump($a);
echo "<br>";
$a = 0x1A; // hexadecimal number (equivalent to 26 decimal)
var_dump($a);
echo "<br>";
$a = 0b1111111; // binary number (equivalent to 255 decimal)
var_dump($a);
$e= 1.234; 
echo "<br>";
var_dump($e);
$b = 1.2e3; 
var_dump($b);
echo "<br>";
$c = 7E-10;
var_dump($c);
echo "<br>";
$d=0.00000009;
var_dump($d);
echo "<hr>";
$var=' y Juan';
$var1='Pepe $var'; /* se escribe lo mismo literar no reconoce el $var */
$var2="Pepe $var";
$var3='Pepe $var en el bar'; /* no escribe el $var no lo reconoce */
$var4='Pepe{$var} en el bar';
$var5='Pepe'.$var .' en el bar';
echo $var1."<br>";
echo $var2."<br>";
echo $var3."<br>";
echo $var4."<br>";
echo $var5."<br>";
$t='Mi pagina ';
$raro= <<<EOT
<div>
<h1>$t</h1>
<hr>
</div>
EOT;
echo $raro;
echo "<br>";
echo "<pre>";
$n=array();
$n[]='pepe';
$n[]='juan';
$n['minimo']=18;
/*
for($i=0;$i<count($n);$i++) { 
	echo $n[$i];
}*/
foreach ($n as $element) {
	echo $element;
}
foreach ($n as $key => $value) {
	echo $key.' => '.$value;
}









?> 
</h1>

</body>
</html>