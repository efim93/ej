<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Primer Proyecto Boostrap</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="./css/miestilo.css">
</head>
<body>
	<header>
		<h1></h1>
	</header>
	<main>
		<div class="container">
      		<div class="row">
	        	<div class="col-md-6 offset-md-3">
					<section>
						<h2>Tus datos son</h2>
							<p>Nombre:<?php echo $_REQUEST['nombre'];?></p>
							 <p>Pais:<?php echo $_REQUEST['pais']; ?></p>
							 <p>Genero:<?php echo $_REQUEST['genero']; ?></p>
							 <p>Mensaje:<?php echo $_REQUEST['mensaje']; ?></p>
							 <?php if(isset($_REQUEST['aficciones'])){?>
							 <p>Aficciones:
							 <?php
							/*  foreach ($_REQUEST['aficciones'] as $element) {
							 	echo $element.',';
									 }*/
								echo implode(',',$_REQUEST['aficciones']);
							}
							  ?>	
							 </p>

<?php

/*
// En versiones de PHP anteriores a la 4.1.0, debería utilizarse $HTTP_POST_FILES en lugar
// de $_FILES.
//phpinfo();
$fichero_subido = $dir_subida . basename($_FILES['ficheros']['name']);

echo '<pre>';
if (move_uploaded_file($_FILES['ficheros']['tmp_name'], $fichero_subido)) {
    echo "El fichero es válido y se subió con éxito.\n";
} else {
    echo "¡Posible ataque de subida de ficheros!\n";
}

echo 'Más información de depuración:';
*/
$dir_subida = 'ficheros/';

foreach($_FILES['ficheros']['name'] as $key => $value){
	move_uploaded_file($_FILES['ficheros']['tmp_name'][$key],$dir_subida.$value);
	echo '<a href="'.$value.'">'.$value.'</><br>';

}

$v=2;
$r=25;
$v=& $r;
var_dump($v);var_dump($r);
$v=12;
var_dump($v);var_dump($r);
$r=33;
var_dump($v);var_dump($r);


?>

					</section>
				</div>
			</div>
		</div>
	</main>
	<footer>
	</footer>
</body>
</html>