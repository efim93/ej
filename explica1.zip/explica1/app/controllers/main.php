<?php 

class main extends Controller{

	public function index(){
				$this->view('main/index');
			}

	public function numero_aleatorio(){

				$this->view('main/numero_aleatorio');
			}
	public function formulario(){
		$this->view('main/formulario');
	}

	public function recibeDatos(){
		$this->view('main/datos');
	}

	}
 ?>